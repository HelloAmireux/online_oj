create view tb_user_view as
select `itcast`.`tb_user`.`id`         AS `id`,
       `itcast`.`tb_user`.`name`       AS `name`,
       `itcast`.`tb_user`.`profession` AS `profession`,
       `itcast`.`tb_user`.`age`        AS `age`,
       `itcast`.`tb_user`.`gender`     AS `gender`,
       `itcast`.`tb_user`.`status`     AS `status`,
       `itcast`.`tb_user`.`createtime` AS `createtime`
from `itcast`.`tb_user`;

